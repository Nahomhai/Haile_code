
public class App {
    private static final double DEQUEUE_THRESHOLD = 0.3;
    private static final double POP_THRESHOLD = 0.1;
    private static final int NUM_PEOPLE = 50;
    private static final double RADIUS = 0.01;

    @SuppressWarnings("deprecation")
    public static void main(String[] args) {
        QueuePop<Integer> line = new QueuePop<>();
        int[][] colors = new int[NUM_PEOPLE][3];

        for (int i = 0; i < NUM_PEOPLE; i++) {
            colors[i] = new int[]{StdRandom.uniform(256), StdRandom.uniform(256), StdRandom.uniform(256)};
        }

        StdDraw.enableDoubleBuffering();

        for (int i = 0; i < NUM_PEOPLE; i++) {
            double random = StdRandom.uniform();
            StdOut.printf("Iteration %d, Random: %.2f\n", i, random);

            if (!line.isEmpty() && random < POP_THRESHOLD) {
                int popped = line.pop();
                StdOut.printf("Person %d left the end of the line (pop)\n", popped);
                drawLine(line, colors, true);
            }

            line.enqueue(i);
            StdOut.printf("Person %d joined the line (enqueue)\n", i);
            drawLine(line, colors, false);

            if (!line.isEmpty() && random < DEQUEUE_THRESHOLD) {
                int dequeued = line.dequeue();
                StdOut.printf("Person %d left the front of the line (dequeue)\n", dequeued);
                drawLine(line, colors, true);
            }

            drawLine(line, colors, false);
            StdDraw.pause(500);
        }
    }

    private static void drawLine(QueuePop<Integer> line, int[][] colors, boolean animate) {
        StdDraw.clear();
        double x = 0.1;
        double y = 0.5;
        int index = 0;

        for (Integer person : line) {
            if (animate && index == 0) {
                y = 0.6;
            } else if (animate && index == line.size() - 1) {
                y = 0.4;
            } else {
                y = 0.5;
            }

            StdDraw.setPenColor(colors[person][0], colors[person][1], colors[person][2]);
            StdDraw.filledCircle(x, y, RADIUS);
            x += 0.02;
            index++;
        }

        StdDraw.show();
    }
}
