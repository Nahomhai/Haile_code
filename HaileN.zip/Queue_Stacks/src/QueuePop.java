import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * QueuePop - A queue implementation with additional pop functionality.
 * This class extends the standard queue operations (enqueue, dequeue)
 * with a pop method that removes and returns the last item in the queue.
 */
public class QueuePop<Item> implements Iterable<Item> {
    private Node<Item> first;
    private Node<Item> last;
    private int n;

    private static class Node<Item> {
        private Item item;
        private Node<Item> next;
        private Node<Item> prev;
    }

    public QueuePop() {
        first = null;
        last = null;
        n = 0;
    }

    public boolean isEmpty() {
        return first == null;
    }

    public int size() {
        return n;
    }

    public Item peek() {
        if (isEmpty()) throw new NoSuchElementException("Queue underflow");
        return first.item;
    }

    public void enqueue(Item item) {
        Node<Item> oldlast = last;
        last = new Node<Item>();
        last.item = item;
        last.next = null;
        last.prev = oldlast;
        if (isEmpty()) first = last;
        else           oldlast.next = last;
        n++;
    }

    public Item dequeue() {
        if (isEmpty()) throw new NoSuchElementException("Queue underflow");
        Item item = first.item;
        first = first.next;
        n--;
        if (isEmpty()) last = null;
        else           first.prev = null;
        return item;
    }

    public Item pop() {
        if (isEmpty()) throw new NoSuchElementException("Queue underflow");
        Item item = last.item;
        last = last.prev;
        n--;
        if (isEmpty()) first = null;
        else {
            last.next = null;
        }
        return item;
    }

    public String toString() {
        StringBuilder s = new StringBuilder();
        for (Item item : this) {
            s.append(item);
            s.append(' ');
        }
        return s.toString();
    }

    public Iterator<Item> iterator() {
        return new ListIterator(first);
    }

    private class ListIterator implements Iterator<Item> {
        private Node<Item> current;

        public ListIterator(Node<Item> first) {
            current = first;
        }

        public boolean hasNext() { return current != null; }
        public void remove()     { throw new UnsupportedOperationException(); }

        public Item next() {
            if (!hasNext()) throw new NoSuchElementException();
            Item item = current.item;
            current = current.next;
            return item;
        }
    }

    public void draw(int ianimate, int pauseTime, int numColors, int[][] colors, double radius) {
        StdDraw.enableDoubleBuffering();
        int qsize = size();

        if (qsize > 0) {
            double maxXlgth = 0.75;
            double translate = 0.5 - maxXlgth / 2.0;
            int numIters = (ianimate != -1) ? 10 : 1;
            double delta = 0.5 / numIters;

            for (int iter = 1; iter <= numIters; iter++) {
                int k = -1;
                StdDraw.clear();

                for (Item j : this) {
                    k++;
                    double x = (qsize == 1) ? 0.5 : (1.0 * k / (qsize - 1)) * maxXlgth + translate;
                    double y = 0.5;
                    if (k == ianimate && ianimate < qsize) y = 0.5 + (iter - 1) * delta;

                    int icolor = Math.floorMod((int) j, numColors);
                    StdDraw.setPenColor(colors[icolor][0], colors[icolor][1], colors[icolor][2]);
                    StdDraw.filledCircle(x, y, radius);
                }

                StdDraw.show();
                StdDraw.pause(pauseTime);
            }
        }
    }

    @SuppressWarnings("deprecation")
    public static void main(String[] args) {
        try {
            QueuePop<Integer> queuePop = new QueuePop<Integer>();
            int num = 10;

            int numColors = num;
            int[][] colors = new int[numColors][3];
            for (int i = 0; i < numColors; i++) {
                colors[i][0] = StdRandom.uniform(256);
                colors[i][1] = StdRandom.uniform(256);
                colors[i][2] = StdRandom.uniform(256);
            }

            double radius = Math.max(0.25 / num, 0.001);
            StdOut.println("Radius for drawing: " + radius);

            for (int i = 0; i < num; i++) {
                queuePop.enqueue(i);
            }

            StdOut.println("\nInitial state of queuePop:");
            StdOut.println(queuePop);

            int iret = queuePop.dequeue();
            StdOut.println("\nDequeued item: " + iret);
            StdOut.println("QueuePop after dequeue:");
            StdOut.println(queuePop);

            iret = queuePop.pop();
            StdOut.println("\nPopped item: " + iret);
            StdOut.println("QueuePop after pop:");
            StdOut.println(queuePop);

            StdOut.println("\nPrinting queuePop using iterator:");
            for (Integer ival : queuePop) {
                StdOut.print(ival + " ");
            }
            StdOut.println();

            queuePop.draw(-1, 1000, numColors, colors, radius);

            StdOut.println("\nAlternating between dequeue and pop until empty:");
            while (!queuePop.isEmpty()) {
                if (queuePop.size() % 2 == 0) {
                    iret = queuePop.dequeue();
                    queuePop.draw(0, 100, numColors, colors, radius);
                    StdOut.println("Dequeued: " + iret);
                } else {
                    iret = queuePop.pop();
                    queuePop.draw(queuePop.size(), 100, numColors, colors, radius);
                    StdOut.println("Popped: " + iret);
                }
                queuePop.draw(-1, 1000, numColors, colors, radius);
            }

            StdDraw.clear();
            StdDraw.show();
        } catch (Exception e) {
            StdOut.println("An error occurred: " + e.getMessage());
            e.printStackTrace();
        }
    }
}


