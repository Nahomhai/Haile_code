// Modern JavaScript using ES6+ features
class EnergyDashboard {
    constructor() {
        this.data = [];
        this.constants = {
            // US-specific energy constants
            CO2_PER_KWH: 0.92,          // US EPA: lbs of CO2 per kWh
            TREES_PER_TON_CO2: 48,      // US Forest Service data
            SOLAR_PANEL_DAILY: 1.5,      // US average solar panel output
            WIND_TURBINE_DAILY: 12,      // US small wind turbine average
            AVG_HOME_DAILY: 30,          // US average home consumption (EIA data)
            COST_PER_KWH: 0.12,         // US average electricity rate
            PEAK_HOURS: {               // US typical peak hours
                start: 14, // 2 PM
                end: 20    // 8 PM
            },
            REGIONS: {
                NORTHEAST: 0.15,    // Higher electricity rates
                MIDWEST: 0.11,
                SOUTH: 0.10,
                WEST: 0.13
            }
        };
        this.region = 'MIDWEST';  // Default to Midwest (where T-Mobile has significant presence)
        this.initialize();
    }
    

    // Initialize the dashboard
    initialize() {
        this.addLoadingAnimation();
        this.generateData();
        this.updateDashboard();
        this.addEventListeners();
        this.animateCards();
    }

    // Add loading animation
    addLoadingAnimation() {
        const loading = document.createElement('div');
        loading.className = 'loading';
        document.body.appendChild(loading);
        setTimeout(() => loading.remove(), 2000);
    }

    // Generate realistic energy consumption data
    generateData() {
        const today = new Date();
        
        // Generate 30 days of data with realistic patterns
        this.data = Array.from({ length: 30 }, (_, i) => {
            const date = new Date(today);
            date.setDate(date.getDate() - i);
            
            // Create realistic usage patterns
            const weekendMultiplier = [0, 6].includes(date.getDay()) ? 1.3 : 1;
            const hourlyPattern = Math.sin((date.getHours() / 24) * Math.PI) + 1;
            const seasonalFactor = Math.cos((date.getMonth() / 12) * 2 * Math.PI) * 0.2 + 1;
            
            const baseLoad = 20;
            const dailyVariation = Math.sin(i * 0.2) * 5;
            const randomVariation = Math.random() * 3;
            
            const consumption = +(
                (baseLoad + dailyVariation + randomVariation) * 
                weekendMultiplier * 
                hourlyPattern * 
                seasonalFactor
            ).toFixed(2);

            const peakPricing = (date.getHours() >= 14 && date.getHours() <= 20) ? 1.5 : 1;
            const cost = +(consumption * this.constants.COST_PER_KWH * peakPricing).toFixed(2);

            return {
                date: date.toISOString().split('T')[0],
                consumption,
                cost,
                peakHours: peakPricing > 1
            };
        });
    }

    // Calculate environmental impact
    calculateEnvironmentalImpact(consumption) {
        const co2 = consumption * this.constants.CO2_PER_KWH;
        return {
            carbonFootprint: +co2.toFixed(2),
            treesNeeded: Math.ceil(co2 / this.constants.TREES_PER_TON_CO2),
            homeEquivalent: +(consumption / this.constants.AVG_HOME_DAILY).toFixed(2)
        };
    }

    // Calculate renewable alternatives
    calculateRenewableAlternatives(consumption) {
        const dailyAvg = consumption / 30;
        return {
            solarPanels: Math.ceil(dailyAvg / this.constants.SOLAR_PANEL_DAILY),
            windTurbines: Math.ceil(dailyAvg / this.constants.WIND_TURBINE_DAILY),
            efficiency: +((1 - (dailyAvg / this.constants.AVG_HOME_DAILY)) * 100).toFixed(1)
        };
    }

    // Update dashboard with new data
    updateDashboard() {
        const totalConsumption = this.data.reduce((sum, day) => sum + day.consumption, 0);
        const avgConsumption = totalConsumption / this.data.length;
        const totalCost = this.data.reduce((sum, day) => sum + day.cost, 0);

        // Update statistics
        this.updateElement('totalConsumption', `${totalConsumption.toFixed(2)} kWh`);
        this.updateElement('avgConsumption', `${avgConsumption.toFixed(2)} kWh`);
        this.updateElement('totalCost', `USD ${totalCost.toFixed(2)}`);

        // Update environmental impact
        const impact = this.calculateEnvironmentalImpact(totalConsumption);
        this.updateElement('carbonFootprint', `${impact.carbonFootprint} lbs`);
        this.updateElement('treesNeeded', `${impact.treesNeeded} trees`);
        this.updateElement('homeEquivalent', `${impact.homeEquivalent} homes`);

        // Update renewable alternatives
        const alternatives = this.calculateRenewableAlternatives(totalConsumption);
        this.updateElement('solarEquivalent', `${alternatives.solarPanels} panels`);
        this.updateElement('windEquivalent', `${alternatives.windTurbines} turbines`);
        this.updateElement('efficiencyRating', `${alternatives.efficiency}%`);

        // Update data table
        this.updateDataTable();
    }

    // Helper method to update DOM elements
    updateElement(id, value) {
        const element = document.getElementById(id);
        if (element) {
            element.textContent = value;
            element.classList.add('updated');
            setTimeout(() => element.classList.remove('updated'), 500);
        }
    }

    // Update the data table with current data
    updateDataTable() {
        const tableBody = document.getElementById('dataTableBody');
        if (!tableBody) return;

        tableBody.innerHTML = '';
        this.data.forEach(day => {
            const impact = this.calculateEnvironmentalImpact(day.consumption);
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${day.date}</td>
                <td>${day.consumption.toFixed(2)}</td>
                <td>${day.cost.toFixed(2)}</td>
                <td>${impact.carbonFootprint}</td>
            `;
            if (day.peakHours) {
                row.classList.add('peak-hours');
            }
            tableBody.appendChild(row);
        });
    }

    // Add interactive event listeners
    addEventListeners() {
        document.querySelectorAll('.stat-card').forEach(card => {
            card.addEventListener('mouseover', () => {
                card.style.transform = 'translateY(-5px)';
            });
            card.addEventListener('mouseout', () => {
                card.style.transform = 'translateY(0)';
            });
        });
    }

    // Animate cards with delay
    animateCards() {
        document.querySelectorAll('.stat-card').forEach((card, index) => {
            card.style.animationDelay = `${index * 0.1}s`;
        });
    }
}

// Initialize dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const dashboard = new EnergyDashboard();
    
    // Refresh data every 5 minutes
    setInterval(() => {
        dashboard.generateData();
        dashboard.updateDashboard();
    }, 300000);
});
